CryptoTrade 5 — mobile-friendly demo starter

IMPORTANT
- This is a front-end demo only, not a real exchange.
- It does not accept payments, authenticate users, perform KYC, connect to a live price feed, store orders on a server, or transfer USDT.
- Do not collect customer money or crypto using this demo.
- Before operating a real VDA service in India, get qualified legal/compliance and tax advice, assess FIU-IND registration/reporting obligations, implement required KYC/AML controls, and arrange security-reviewed backend/wallet/payment infrastructure.

Files
- index.html: complete responsive demo website (HTML/CSS/JavaScript)

Mobile preview
1. Download and extract the ZIP on your phone, or open index.html in an HTML preview app/browser that supports local files.
2. For public hosting, create a GitHub account.
3. Create a PUBLIC repository named cryptotrade5-demo (GitHub Pages free hosting requires a public repo on GitHub Free).
4. Add/upload index.html to the repository root.
5. Open repository Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
7. Wait for deployment and open the URL shown in Settings > Pages.

Note: GitHub Pages hosts static files. It cannot securely implement real accounts, private KYC records, server-side order matching, custody or payment processing by itself. Keep this demo clearly labelled as a demo until a compliant backend is built and reviewed.
